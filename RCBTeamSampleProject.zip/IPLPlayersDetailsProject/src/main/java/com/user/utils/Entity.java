package com.user.utils;

import org.json.simple.JSONArray;

public class Entity {
	public  static final int  PlayingPlayersNumber=11;
	public  static final String  jsonArrayKeyValue="player";
	public static JSONArray teamDetails=null;
	
	
	public static JSONArray getTeamDetails() {
		return teamDetails;
	}
	public static void setTeamDetails(JSONArray teamDetails) {
		Entity.teamDetails = teamDetails;
	}

}
