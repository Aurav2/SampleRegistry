package com.user.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JsonUtility {
	/**
	 * This function reads json file from specify path and return as List of JSON Array
	 * 
	 * @param jsonFilePath
	 * @return
	 * @throws ParseException
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public JSONArray readTeamRCBJSONFile(String jsonFilePath, String keyValue)
			throws FileNotFoundException, IOException, ParseException {
		
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader(jsonFilePath));
		JSONObject josnObject = (JSONObject) obj;
		JSONArray arrayValues = (JSONArray) josnObject.get(keyValue);
		Entity.setTeamDetails(arrayValues);
		return arrayValues;	
	}
	
	
	/**
	 * This function reads json file from specify path and return as List of specific child node
	 * 
	 * @param jsonFilePath
	 * @return
	 * @throws ParseException
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	public List<String> returnRCBPlayersDetials(String childNodeValue)
			throws FileNotFoundException, IOException, ParseException {
		List<String> playersDetails=new ArrayList<String>();
		JSONArray arrayValues=Entity.getTeamDetails();
		for(int i=0;i<arrayValues.size();i++) {
			JSONObject	playersList=(JSONObject)arrayValues.get(i);
			if(playersList.get("country").equals(childNodeValue)) {
				playersDetails.add((String)playersList.get("country"));
			}
			else if(playersList.get("role").equals(childNodeValue)) 
			{
				playersDetails.add((String)playersList.get("role"));
			}
		}
		return playersDetails;	
	}
	
}
