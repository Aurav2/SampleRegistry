package com.user.stepdefinations;

import java.util.List;

import org.json.simple.JSONArray;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.user.utils.Entity;
import com.user.utils.JsonUtility;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class PlayersDetails extends JsonUtility{
	
	public String dirPath = System.getProperty("user.dir");
	public String getTeamRCBPJsonFilePath = dirPath + "/src/test/resources/TestData/" + "TeamRCB.json";
	JsonUtility utility=null;
	
	@Given("^The RCB team players finalized for upcoming match$")
	public void the_RCB_team_players_finalized_for_upcoming_match() throws Throwable {
		System.out.println("The RCB team players finalized for upcoming match");
		Reporter.addStepLog("The RCB team players finalized for upcoming match");
	}

	@When("^Finalized RCB Playes list has been extracted from json$")
	public void finalized_RCB_Playes_list_has_been_extracted_from_json() throws Throwable {
		utility=new JsonUtility();
		JSONArray listOfPlayers=utility.readTeamRCBJSONFile(getTeamRCBPJsonFilePath, Entity.jsonArrayKeyValue);
		Assert.assertEquals(listOfPlayers.size(),Entity.PlayingPlayersNumber,"No geeting fron the API is not matching with expected results");
		System.out.println("Successfully Verified playing players are "+Entity.PlayingPlayersNumber);
		Reporter.addStepLog("Successfully Verified playing players are "+Entity.PlayingPlayersNumber);
	}

	
	@Then("^Validates that the team has only FOUR foregin players \"([^\"]*)\" \"([^\"]*)\"$")
	public void validates_that_the_team_has_only_FOUR_foregin_players(int expectedForigenPlayers, String country) throws Throwable {
		utility=new JsonUtility();
		List<String> indianPlayerList=utility.returnRCBPlayersDetials(country);
		Assert.assertEquals((Entity.PlayingPlayersNumber-indianPlayerList.size()),expectedForigenPlayers,"No forigen players getting from the API is not matching with expected results");
		System.out.println("Successfully Verified forigen playing players are "+expectedForigenPlayers);
		Reporter.addStepLog("Successfully Verified forigen playing players are "+expectedForigenPlayers);
	}

	@Then("^Validates that there is at least ONE wicket keeper \"([^\"]*)\"$")
	public void validates_that_there_is_at_least_ONE_wicket_keeper(String role) throws Throwable {
		utility=new JsonUtility();
		List<String> playerRoleList=utility.returnRCBPlayersDetials(role);
		Assert.assertTrue(playerRoleList.contains(role),"Wicket kepeer is not included in team");
		System.out.println("Successfully Verified that there is at least ONE wicket keeper");
		Reporter.addStepLog("Successfully Verified that there is at least ONE wicket keeper");
	}
}
